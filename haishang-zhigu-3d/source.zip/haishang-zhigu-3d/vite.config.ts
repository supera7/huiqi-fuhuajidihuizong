import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";
export default defineConfig({
 plugins:[react()],
 base:"./",
 resolve:{alias:{"@":fileURLToPath(new URL(".",import.meta.url))}},
 build:{rollupOptions:{output:{entryFileNames:"app-[hash].js",chunkFileNames:"chunk-[name]-[hash].js",assetFileNames:"[name]-[hash][extname]"}}}
});
