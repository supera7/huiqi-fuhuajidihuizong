import { createRoot } from "react-dom/client";
import Home from "./app/page";
import "./app/globals.css";
import "./app/campus.css";
import "./app/tour.css";
import "./app/spatial.css";
createRoot(document.getElementById("root")!).render(<Home />);
