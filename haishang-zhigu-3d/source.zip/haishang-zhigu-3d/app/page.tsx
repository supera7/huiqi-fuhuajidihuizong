"use client";

import { useCallback, useEffect, useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, Box, ChevronRight, Compass, Expand, Layers3, Leaf, Lightbulb, MapPin, Minus, Plus, Moon, MoveUpRight, Pause, Play, RotateCcw, Shrink, Sparkles, Sun, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import CampusScene from "./scene";
import CampusTour from "./campus-tour";
import SpatialHud from "./spatial-hud";
import type { PhotoView } from "./space-photo";
import type { JourneyPhase } from "./spatial-director";
import type { TourId, SpaceId } from "./tour-data";

const spaces = [
  { title: "创新孵化", english: "INCUBATE", tag: "让灵感迈出第一步", icon: Lightbulb, description: "从一个想法，到一家企业。让创业者在开放的交流中找到方向，在彼此的连接中积蓄成长的力量。", items: ["创业想法梳理", "商业模式探索", "创业经验交流"], location: "创新孵化中心" },
  { title: "成长加速", english: "ACCELERATE", tag: "陪伴企业向上生长", icon: Layers3, description: "每一次成长，都需要新的支持。围绕中小企业的发展需求，探索资源、经验与协作的更多可能。", items: ["企业成长交流", "产业资源连接", "合作机会探索"], location: "企业成长空间" },
  { title: "生态共创", english: "CONNECT", tag: "与志同道合者同行", icon: Box, description: "让不同领域的想法在这里相遇。以开放共享的创业氛围，让一人的灵感成为一群人的可能。", items: ["开放共享空间", "创业社群交流", "跨领域协作"], location: "开放共创空间" },
  { title: "绿色未来", english: "THRIVE", tag: "在海南，与未来相遇", icon: Leaf, description: "把海南的自然灵感带入创业日常。在工作与生活之间，留出思考、交流和发现新可能的空间。", items: ["自然与创意融合", "灵活工作理念", "可持续成长愿景"], location: "灵感生态花园" },
];

export default function Home() {
  const [immersive, setImmersive] = useState(false);
  const [day, setDay] = useState(false);
  const [rotate, setRotate] = useState(true);
  const [reset, setReset] = useState(0);
  const [selected, setSelected] = useState(0);
  const [view, setView] = useState(0);
  const [viewRequest, setViewRequest] = useState(0);
  const [zoomCommand, setZoomCommand] = useState(0);
  const [detail, setDetail] = useState<number | "services" | "ecosystem" | "about" | null>(null);
  const [ready, setReady] = useState(false);
  const [menu, setMenu] = useState(false);
  const [tourMode, setTourMode] = useState(false);
  const [tourSelection, setTourSelection] = useState<TourId | null>(null);
  const [room, setRoom] = useState<SpaceId | null>(null);
  const [roomRequest, setRoomRequest] = useState(0);
  const [photoView, setPhotoView] = useState<PhotoView>("full");
  const [journeyPhase, setJourneyPhase] = useState<JourneyPhase>("campus");
  const [skipJourney, setSkipJourney] = useState(0);
  const hasRoom = room!==null || journeyPhase!=="campus";
  const enterRoom = useCallback((id:SpaceId) => {
    setRoom(id); setRoomRequest(n=>n+1); setPhotoView("full"); setRotate(false); setImmersive(true); setTourSelection(null); setDetail(null); setMenu(false);
    window.scrollTo({top:0,behavior:"instant"});
  }, []);
  const leaveRoom = useCallback(() => {setRoom(null);setRoomRequest(n=>n+1);setView(0);setViewRequest(n=>n+1);setRotate(false);}, []);
  const changePhotoView = useCallback((next:PhotoView) => setPhotoView(next), []);
  const openTour = useCallback((id: TourId) => { setTourSelection(id); setRotate(false); setMenu(false); }, []);
  const handleReady = useCallback(() => setReady(true), []);
  const focusView = useCallback((index: number) => { setView(index); setViewRequest(n => n + 1); setRotate(false); }, []);
  const openSpace = useCallback((index: number) => { setSelected(index); setDetail(index); }, []);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) setRotate(false);
    const key = (e: KeyboardEvent) => { if (e.key === "Escape" && detail === null && tourSelection === null) { if(room!==null)leaveRoom();else if(journeyPhase==="campus")setImmersive(false); setMenu(false); } };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [detail, tourSelection, room, journeyPhase, leaveRoom]);
  const explore = () => { setImmersive(value => !value); setMenu(false); };

  return (
    <main className={`experience modeled-campus ${immersive ? "is-immersive" : ""} ${day ? "is-day" : ""} ${hasRoom ? "has-room" : ""}`}>
      <div className="ambient-glow" aria-hidden="true" />
      <header className="site-header">
        <a className="brand" href="./" aria-label="海南海商智谷首页"><span className="brand-symbol"><Layers3 strokeWidth={1.5} /></span><span><strong>海商智谷<span className="brand-period">.</span></strong><small>HAISHANG INNOVATION VALLEY</small></span></a>
        <nav className={menu ? "navigation mobile-open" : "navigation"} aria-label="主导航">
          <button className={detail === null ? "active" : ""} onClick={() => { setImmersive(false); setMenu(false); }}>园区探索</button>
          <button onClick={() => openTour("all")}>实景空间</button>
          <button onClick={() => { setDetail("ecosystem"); setMenu(false); }}>创业生态</button>
          <button onClick={() => { setDetail("services"); setMenu(false); }}>孵化服务</button>
          <button onClick={() => { setDetail("about"); setMenu(false); }}>关于智谷</button>
        </nav>
        <Button className="header-cta" variant="outline" onClick={explore}>{immersive ? "返回首页" : "开启探索"}<ArrowUpRight size={17} /></Button>
        <Button className="mobile-menu" variant="ghost" size="icon" aria-label={menu ? "关闭菜单" : "打开菜单"} aria-expanded={menu} onClick={() => setMenu(!menu)}>{menu ? <X /> : <span className="menu-lines">☰</span>}</Button>
      </header>
      <section className="hero" aria-label="海南海商智谷交互园区">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" />立足海南 · 创见未来</div>
          <h1>让好想法，<br /><span>在这里生长</span><span className="heading-period">。</span></h1>
          <p className="hero-description">一座园区，无限可能。<br />海南海商智谷，为中小企业创新创业而生。</p>
          <div className="hero-actions"><Button className="primary-cta" onClick={()=>enterRoom("cowork")}>沉浸走进空间<ArrowUpRight size={20} /></Button><Button className="secondary-cta" variant="ghost" onClick={() => openTour("all")}><Play size={17} />观看园区实景</Button></div>
          <div className="hero-footnote"><Sparkles size={15} /><span>从园区到室内，走进 8 个真实功能空间</span></div>
        </div>
        <div className="scene-area" data-view={view} data-tour={tourMode}>
          <div className="scene-coordinate"><span>H A I N A N</span><small>EXPLORE IN THREE DIMENSIONS</small></div>
          <div className="scene-tour-toggle" role="group" aria-label="园区探索方式"><button aria-pressed={!tourMode} onClick={() => setTourMode(false)}>建筑外观</button><button aria-pressed={tourMode} onClick={() => { setTourMode(true); focusView(0); }}><Play size={13}/>功能导览</button></div>
          <div className="camera-presets" aria-label="建筑观察视角">{["园区全景","沿街立面","屋顶庭院","孵化器入口"].map((name,i)=><button key={name} aria-pressed={view===i} onClick={()=>focusView(i)}>{name}</button>)}</div>
          <CampusScene day={day} autoRotate={rotate} reset={reset} view={view} viewRequest={viewRequest} zoomCommand={zoomCommand} immersive={immersive} tourMode={tourMode} room={room} roomRequest={roomRequest} photoView={photoView} onPhotoView={changePhotoView} skipJourney={skipJourney} onJourneyPhase={setJourneyPhase} onTourSelect={id=>id!=="all"&&enterRoom(id)} onSelect={focusView} onReady={handleReady} />
          {!ready && <div className="scene-loading"><Compass className="loading-icon" /><span>正在构建 3D 创业园区</span></div>}
          <div className="scene-watermark">INNOVATION<br /><span>STARTS HERE.</span></div>
          <div className="scene-caption"><span className="caption-cross">+</span><span>{tourMode ? "点击空间标记，观看空间实景" : "海商智谷 · 立体创业园区"}<small>{tourMode ? "标记为导览索引，非房间实际位置" : "实景参考建模 / 3D CAMPUS"}</small></span></div>
        </div>
        {immersive && <div className="explore-heading"><span>自由探索模式</span><h2>每一面，都有新发现。</h2><p>360° 拖动探索，点击标记近看建筑细节。</p></div>}
        <div className="scene-controls"><span className="drag-hint"><Compass size={15} />360° 旋转 · 滚轮 / 双指缩放</span><div className="control-group">
          <Button variant="ghost" size="icon" aria-label={rotate ? "暂停自动旋转" : "开始自动旋转"} title={rotate ? "暂停旋转" : "自动旋转"} onClick={() => setRotate(!rotate)}>{rotate ? <Pause /> : <Play />}</Button>
          <Button variant="ghost" size="icon" aria-label={day ? "切换夜间氛围" : "切换日间氛围"} title={day ? "夜间氛围" : "日间氛围"} onClick={() => setDay(!day)}>{day ? <Moon /> : <Sun />}</Button>
          <Button variant="ghost" size="icon" aria-label="拉近建筑" title="拉近建筑" onClick={()=>setZoomCommand(n=>n+1)}><Plus/></Button>
          <Button variant="ghost" size="icon" aria-label="拉远建筑" title="拉远建筑" onClick={()=>setZoomCommand(n=>n-1)}><Minus/></Button>
          <Button variant="ghost" size="icon" aria-label="重置园区视角" title="重置视角" onClick={() => { setReset(n => n + 1); setView(0); }}><RotateCcw /></Button><span className="control-divider" />
          <Button variant="ghost" size="icon" aria-label={immersive ? "退出沉浸探索" : "进入沉浸探索"} title={immersive ? "退出沉浸探索" : "沉浸探索"} onClick={explore}>{immersive ? <Shrink /> : <Expand />}</Button>
        </div></div>
        <div className="hero-index"><span>01</span><i />探索无限可能</div>
        {hasRoom&&<SpatialHud room={room} phase={journeyPhase} view={photoView} onEnter={enterRoom} onLeave={leaveRoom} onView={changePhotoView} onSkip={()=>setSkipJourney(n=>n+1)} onVideo={openTour}/>}
      </section>
      <CampusTour onEnter={enterRoom} selection={tourSelection} onSelect={openTour} onClose={() => setTourSelection(null)} />
      <section className="pathways" aria-label="创业成长路径">
        <div className="pathway-heading"><span>YOUR NEXT CHAPTER</span><p>从一粒灵感，到一片未来。</p><ArrowDown size={18} /></div>
        <div className="pathway-grid">{spaces.map((space, index) => <button key={space.english} className={`pathway ${selected === index ? "selected" : ""}`} onClick={() => openSpace(index)}><span className="pathway-number">0{index + 1}</span><span className="pathway-icon"><space.icon size={25} strokeWidth={1.4} /></span><span className="pathway-copy"><span className="pathway-title">{space.title}<small>{space.english}</small></span><span className="pathway-tag">{space.tag}</span></span><MoveUpRight size={18} className="pathway-arrow" /></button>)}</div>
      </section>
      <footer className="site-footer"><span><MapPin size={13} />中国 · 海南</span><span>中小企业创新创业孵化基地</span><span className="footer-end">IDEAS GROW HERE<Leaf size={13} /></span></footer>
      <Dialog open={detail !== null} onOpenChange={open => { if (!open) setDetail(null); }}><DialogContent className="info-dialog" showCloseButton={false}>
        <DialogClose asChild><Button className="dialog-close" variant="ghost" size="icon" aria-label="关闭详情"><X /></Button></DialogClose>
        <span className="dialog-eyebrow">HAISHANG INNOVATION VALLEY</span>
        <DialogTitle>{typeof detail === "number" ? spaces[detail].location : detail === "services" ? "让创业的每一步，更有方向。" : detail === "ecosystem" ? "好的生态，让彼此成就。" : "海商智谷，生长的地方。"}</DialogTitle>
        <DialogDescription>{typeof detail === "number" ? spaces[detail].description : detail === "services" ? "围绕中小企业从想法到成长的不同阶段，探索适合自己的创新创业路径。" : detail === "ecosystem" ? "创业者、创意与产业资源在这里相遇。以开放的连接，让想法有机会走得更远。" : "海南海商智谷产业园，是面向中小企业的创新创业孵化基地。立足海南，汇聚创业灵感，陪伴企业成长。"}</DialogDescription>
        {typeof detail === "number" ? <div className="detail-items">{spaces[detail].items.map((item, i) => <div key={item}><span>0{i + 1}</span>{item}<ArrowUpRight size={18} /></div>)}</div> : <div className="dialog-spaces">{spaces.slice(0, detail === "about" ? 2 : 4).map((space, i) => <button key={space.english} onClick={() => openSpace(i)}><space.icon size={23} /><span>{space.title}<small>{space.tag}</small></span><ChevronRight size={18} /></button>)}</div>}
        <p className="concept-note">3D 建筑参考园区实景照片制作；尺寸、庭院内部与未展示的背面为示意表达。具体场地及服务以园区实际为准。</p>
        <Button className="dialog-explore" onClick={() => { setDetail(null); setImmersive(true); }}>在 3D 园区中探索<ArrowRight size={17} /></Button>
      </DialogContent></Dialog>
    </main>
  );
}
