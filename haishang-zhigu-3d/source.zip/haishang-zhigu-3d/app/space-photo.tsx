"use client";

import { useEffect, useRef, useState } from "react";
import type { KeyboardEvent, PointerEvent } from "react";
import { ImageIcon, RotateCcw } from "lucide-react";
import { tourSpaces, SpaceId } from "./tour-data";

export type PhotoView = "full" | "detail";
type Props = {id:SpaceId;view:PhotoView;onView:(view:PhotoView)=>void};
const clamp=(n:number,max:number)=>Math.max(-max,Math.min(max,n));

export default function SpacePhoto({id,view,onView}:Props) {
  const space=tourSpaces.find(item=>item.id===id)!;
  const frame=useRef<HTMLDivElement>(null);
  const pointers=useRef(new Map<number,{x:number;y:number}>());
  const pinch=useRef(0);
  const [pan,setPan]=useState({x:0,y:0});
  const [loaded,setLoaded]=useState(false),[failed,setFailed]=useState(false),[retry,setRetry]=useState(0);
  const zoomed=view==="detail",scale=zoomed?1.65:1;
  useEffect(()=>{setPan({x:0,y:0});},[view]);
  const shift=(x:number,y:number)=>{
    const el=frame.current;if(!el)return;
    setPan(p=>({x:clamp(p.x+x,el.clientWidth*.325),y:clamp(p.y+y,el.clientHeight*.325)}));
  };
  useEffect(()=>{
    const el=frame.current!;
    const wheel=(e:WheelEvent)=>{e.preventDefault();onView(e.deltaY<0?"detail":"full");};
    el.addEventListener("wheel",wheel,{passive:false});
    const resize=new ResizeObserver(()=>setPan({x:0,y:0}));resize.observe(el);
    return()=>{el.removeEventListener("wheel",wheel);resize.disconnect();};
  },[onView]);
  function down(e:PointerEvent<HTMLDivElement>) {
    if((e.target as HTMLElement).closest("button"))return;
    e.currentTarget.setPointerCapture(e.pointerId);pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pointers.current.size===2){const [a,b]=[...pointers.current.values()];pinch.current=Math.hypot(a.x-b.x,a.y-b.y);}
  }
  function move(e:PointerEvent<HTMLDivElement>) {
    const old=pointers.current.get(e.pointerId);if(!old)return;
    pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pointers.current.size===2){const[a,b]=[...pointers.current.values()],ratio=Math.hypot(a.x-b.x,a.y-b.y)/(pinch.current||1);if(ratio>1.15)onView("detail");else if(ratio<.85)onView("full");}
    else if(zoomed)shift(e.clientX-old.x,e.clientY-old.y);
  }
  const up=(e:PointerEvent<HTMLDivElement>)=>{pointers.current.delete(e.pointerId);};
  function key(e:KeyboardEvent<HTMLDivElement>) {
    if(["+","=","-","Home","ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key))e.preventDefault();
    if(e.key==="+"||e.key==="=")onView("detail");if(e.key==="-"||e.key==="Home")onView("full");
    if(zoomed){if(e.key==="ArrowLeft")shift(35,0);if(e.key==="ArrowRight")shift(-35,0);if(e.key==="ArrowUp")shift(0,35);if(e.key==="ArrowDown")shift(0,-35);}
  }
  return <div className="space-photo">
    <figure className="photo-presentation">
      <figcaption><span><ImageIcon size={14}/>园区原始实景</span><span>{space.category}</span></figcaption>
      <div ref={frame} className={`photo-window ${zoomed?"is-zoomed":""}`} tabIndex={0} role="region" aria-label={`${space.name}实景照片；加减键缩放，放大后拖动或使用方向键查看`} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onLostPointerCapture={up} onKeyDown={key} onDoubleClick={()=>onView(zoomed?"full":"detail")}>
        <div className={`photo-entry ${loaded?"is-loaded":""}`}><img key={retry} src={space.image} alt={`${space.name}真实画面，截取自园区提供的介绍视频`} width={568} height={320} draggable={false} style={{transform:`translate(${zoomed?pan.x:0}px,${zoomed?pan.y:0}px) scale(${scale})`}} onLoad={()=>setLoaded(true)} onError={()=>setFailed(true)}/></div>
        {!loaded&&!failed&&<span className="photo-notice" role="status">正在载入实景画面…</span>}
        {failed&&<div className="photo-notice" role="alert"><span>实景图片暂时未能加载</span><button onClick={()=>{setFailed(false);setLoaded(false);setRetry(n=>n+1);}}><RotateCcw size={15}/>重新加载</button></div>}
      </div>
    </figure>
  </div>;
}
