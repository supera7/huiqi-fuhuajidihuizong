export const TOUR_VIDEO = "./campus-tour.mp4";
export const tourSpaces = [
  { id: "cowork", name: "开放办公", category: "协作办公", start: 4.45, end: 6.7, image: "./cowork.jpg", description: "成排工位与开放办公大厅，让日常办公和团队协作在同一个空间展开。", features: ["开放工位", "办公大厅"] },
  { id: "offices", name: "独立办公", category: "专注工作", start: 10.5, end: 12.9, image: "./offices.jpg", description: "玻璃隔断、百叶与沿廊排列的房间，呈现园区独立办公空间的实景。", features: ["玻璃隔间", "沿廊办公"] },
  { id: "meeting", name: "共享会议", category: "团队交流", start: 14.35, end: 15.35, image: "./meeting.jpg", description: "长桌、环绕座椅与会议空间。视频后段还展示了另一处配有投影幕的会议室。", features: ["长桌会议", "团队讨论"] },
  { id: "lounge", name: "会客交流", category: "轻松洽谈", start: 15.4, end: 16.35, image: "./lounge.jpg", description: "临窗沙发、茶几与茶具，留出一处坐下来交谈、接待来访者的空间。", features: ["临窗会客", "茶歇洽谈"] },
  { id: "reading", name: "阅读空间", category: "灵感停留", start: 1.35, end: 1.98, image: "./reading.jpg", description: "书架围合的公共阅读角，搭配长桌与座椅，为工作间隙留一点阅读时间。", features: ["公共书架", "阅读长桌"] },
  { id: "reception", name: "前台服务", category: "到访接待", start: 16.8, end: 17.7, image: "./reception.jpg", description: "园区标识墙与前台接待区域。完整视频中还可以看到门卫及快递代收等配套介绍。", features: ["园区接待", "来访引导"] },
  { id: "parking", name: "门卫停车", category: "便捷到达", start: 18.95, end: 19.98, image: "./parking.jpg", description: "入口门岗、道闸与树荫停车区域，连接日常通勤和园区到访。", features: ["入口门岗", "停车区域"] },
  { id: "dining", name: "园区食堂", category: "日常配套", start: 20.9, end: 22.16, image: "./dining.jpg", description: "圆桌、餐椅与明亮的用餐大厅，展现园区工作日里的餐饮配套空间。", features: ["用餐大厅", "日常餐饮"] },
] as const;
export type SpaceId = typeof tourSpaces[number]["id"];
export type TourId = SpaceId | "all";
export const tourMarkerIds: TourId[] = ["cowork", "meeting", "reception", "dining"];
export const tourMarkerLabels = ["办公空间", "会议与交流", "前台接待", "生活配套"];
export function tourTime(time: number, precise = false) { return `00:${precise ? time.toFixed(1).padStart(4, "0") : String(Math.floor(time)).padStart(2, "0")}`; }
