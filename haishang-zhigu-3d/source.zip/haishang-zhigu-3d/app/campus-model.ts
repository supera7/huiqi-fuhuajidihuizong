import * as THREE from "three";

/** Proportional architectural interpretation of the two supplied reference photos. */
export function createCampusModel() {
  const root = new THREE.Group();
  root.name = "Haishang architectural campus";
  const pickables: THREE.Object3D[] = [];
  const textures: THREE.Texture[] = [];
  const standard = (color: number, roughness = .65, metalness = .15) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
  const m = {
    base: standard(0x09252c, .34, .7), paving: standard(0x547468), curb: standard(0x9cb5a0),
    wall: standard(0xd5d0b9), cream: standard(0xe0deca), redwood: standard(0x985a43),
    gold: standard(0xad9361, .45, .25), roof: standard(0x3f6570, .46, .4), roofTop: standard(0x859489),
    glass: new THREE.MeshStandardMaterial({ color: 0x1b4752, metalness: .65, roughness: .18, emissive: 0x285955, emissiveIntensity: .2 }),
    glassWarm: new THREE.MeshStandardMaterial({ color: 0x728c78, metalness: .45, roughness: .23, emissive: 0xaec780, emissiveIntensity: .28 }),
    wood: standard(0x865d3e), woodDark: standard(0x573929), lantern: standard(0xb72428, .7),
    brass: standard(0xd7af64, .3, .5), stone: standard(0xa0b0b2), grass: standard(0x295d43, .92),
    leaf: new THREE.MeshStandardMaterial({ color: 0x498354, roughness: .82, side: THREE.DoubleSide }),
    trunk: standard(0x8e9170), road: standard(0x183532, .96), white: standard(0xcdd8c5),
    black: standard(0x142127), chrome: standard(0xadc9c3, .28, .7), pinkRoof: standard(0x926875),
    cyan: new THREE.MeshBasicMaterial({ color: new THREE.Color(0x70edce).multiplyScalar(1.65) }),
    lime: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xbce98a).multiplyScalar(1.7) }),
    warm: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xf0cf8c).multiplyScalar(1.45) }),
  };
  const boxGeometry = new THREE.BoxGeometry(1, 1, 1);
  const sphereGeometry = new THREE.IcosahedronGeometry(1, 1);
  const cylinderGeometry = new THREE.CylinderGeometry(1, 1, 1, 10);
  const batches = new Map<string, { geometry: THREE.BufferGeometry; material: THREE.Material; matrices: THREE.Matrix4[] }>();
  const dummy = new THREE.Object3D();
  function instance(geometry: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number, rx = 0, ry = 0, rz = 0) {
    const key = geometry.uuid + material.uuid;
    let batch = batches.get(key);
    if (!batch) { batch = { geometry, material, matrices: [] }; batches.set(key, batch); }
    dummy.position.set(x, y, z); dummy.scale.set(sx, sy, sz); dummy.rotation.set(rx, ry, rz); dummy.updateMatrix(); batch.matrices.push(dummy.matrix.clone());
  }
  const box = (x: number, y: number, z: number, w: number, h: number, d: number, mat: THREE.Material, ry = 0) => instance(boxGeometry, mat, x, y, z, w, h, d, 0, ry);
  function solid(x: number, y: number, z: number, w: number, h: number, d: number, mat: THREE.Material, view: number) {
    const mesh = new THREE.Mesh(boxGeometry, mat); mesh.position.set(x, y, z); mesh.scale.set(w, h, d); mesh.castShadow = true; mesh.receiveShadow = true; mesh.userData.view = view; root.add(mesh); pickables.push(mesh); return mesh;
  }
  function rounded(w: number, d: number, h: number, radius: number, y: number, mat: THREE.Material) {
    const shape = new THREE.Shape(), x = -w / 2, z = -d / 2, r = radius;
    shape.moveTo(x + r, z); shape.lineTo(x + w - r, z); shape.quadraticCurveTo(x + w, z, x + w, z + r);
    shape.lineTo(x + w, z + d - r); shape.quadraticCurveTo(x + w, z + d, x + w - r, z + d);
    shape.lineTo(x + r, z + d); shape.quadraticCurveTo(x, z + d, x, z + d - r);
    shape.lineTo(x, z + r); shape.quadraticCurveTo(x, z, x + r, z);
    const geometry = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: true, bevelSize: .075, bevelThickness: .05, bevelSegments: 2, curveSegments: 8 });
    geometry.translate(0, 0, -h / 2); geometry.rotateX(-Math.PI / 2);
    const mesh = new THREE.Mesh(geometry, mat); mesh.position.y = y; mesh.receiveShadow = true; root.add(mesh);
  }
  rounded(24, 17.4, .75, 1.2, -.6, m.base);
  rounded(24.04, 17.44, .04, 1.2, -.31, m.cyan);
  rounded(24.18, 17.58, .19, 1.2, -.12, m.paving);
  rounded(23.6, 17, .04, 1, .005, m.curb);
  rounded(23.3, 16.7, .035, .9, .04, m.paving);
  box(0, .11, -.2, 21.5, .13, 12, m.curb);
  box(0, .19, -1.4, 20.8, .06, 9.6, m.paving);

  // Three-storey street-facing bar; stepped lower shop volume to the right.
  solid(-1.1, 1.85, 1.2, 15, 3.4, 2.65, m.wall, 1);
  solid(7.72, 1.36, 1.2, 2.64, 2.42, 2.65, m.wall, 1);
  box(-1.1, .29, 2.63, 15.1, .28, .25, m.woodDark);
  box(7.72, .29, 2.63, 2.75, .28, .25, m.woodDark);
  const front = 2.54;
  for (let bay = 0; bay < 21; bay++) {
    const x = -8.2 + bay * .7;
    for (let floor = 0; floor < 3; floor++) {
      const y = .79 + floor * 1.08;
      // Entry replaces the ground-floor windows in its two central bays.
      if (!(floor === 0 && x > .35 && x < 2.85)) {
        box(x, y, front + .02, .51, .82, .04, (bay + floor * 3) % 6 === 0 ? m.glassWarm : m.glass);
        box(x, y, front + .052, .035, .85, .045, m.chrome);
        box(x, y - .22, front + .052, .53, .022, .04, m.chrome);
      }
    }
    box(x - .33, 1.87, front + .07, .13, 3.4, .12, m.redwood);
    box(x + .33, 1.87, front + .072, .033, 3.4, .13, m.cream);
  }
  // Continue the window rhythm onto courtyard-facing and end walls for a full 360° model.
  for (let bay = 0; bay < 21; bay++) {
    const x = -8.2 + bay * .7;
    for (let floor = 0; floor < 3; floor++) {
      box(x, .79 + floor * 1.08, -.15, .48, .76, .045, m.glass);
      box(x, .79 + floor * 1.08, -.182, .035, .78, .04, m.redwood);
    }
  }
  for (const x of [-8.622, 9.063]) for (let bay = 0; bay < 3; bay++) {
    for (let floor = 0; floor < (x < 0 ? 3 : 2); floor++)
      box(x, .79 + floor * 1.08, .4 + bay * .8, .045, .76, .52, m.glass);
  }
  for (const y of [1.29, 2.37, 3.46]) {
    box(-1.1, y, front + .13, 15.17, .115, .22, m.cream);
    box(-1.1, y - .08, front + .125, 15.1, .033, .22, m.roof);
  }
  for (let i = 0; i < 4; i++) for (let floor = 0; floor < 2; floor++) {
    const x = 6.73 + i * .64, y = .8 + floor * 1.05;
    box(x, y, front + .024, .52, .8, .045, m.glass);
    box(x - .3, 1.37, front + .07, .1, 2.4, .14, m.redwood);
    box(x, y, front + .06, .03, .8, .035, m.cream);
  }
  box(7.72, 2.64, 1.2, 2.92, .18, 2.9, m.cream);
  box(7.72, 2.77, 1.2, 2.65, .09, 2.65, m.roofTop);
  box(7.72, 1.28, front + .12, 2.87, .12, .2, m.cream);

  function hipRoof(x: number, y: number, z: number, w: number, d: number, h: number, mat: THREE.Material) {
    const verts = [new THREE.Vector3(-w/2,0,-d/2),new THREE.Vector3(w/2,0,-d/2),new THREE.Vector3(w/2,0,d/2),new THREE.Vector3(-w/2,0,d/2),new THREE.Vector3(-w*.28,h,0),new THREE.Vector3(w*.28,h,0)];
    const faces = [0,4,5, 0,5,1, 3,2,5, 3,5,4, 0,3,4, 1,5,2, 0,1,2, 0,2,3];
    const geometry = new THREE.BufferGeometry().setFromPoints(faces.map(i=>verts[i])); geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry,mat); mesh.position.set(x,y,z); mesh.castShadow = true; root.add(mesh);
    box(x,y-.035,z,w+.04,.075,d+.04,m.cream);
    box(x,y+h+.012,z,w*.6,.035,.045,m.roof);
  }
  box(-1.1, 3.61, 1.2, 15.16, .2, 2.84, m.cream);
  box(-1.1, 3.73, 1.13, 14.87, .08, 2.6, m.roofTop);
  // The reference's blue-grey tiled cornice, kept low instead of turning into towers.
  hipRoof(-1.1, 3.65, 2.53, 15.22, .63, .21, m.roof);
  for (let i = 0; i < 65; i++) box(-8.65 + i * .235, 3.77, 2.55, .016, .035, .57, m.chrome);
  for (const z of [-.17, 2.33]) box(-1.1, 3.86, z, 15, .2, .09, m.cream);
  for (const x of [-8.59, 6.39]) box(x, 3.86, 1.1, .09, .2, 2.55, m.cream);

  // Two ornate facade pylons with inset arched glazing and small hipped caps.
  const archShape = new THREE.Shape();
  archShape.moveTo(-.2,0); archShape.lineTo(.2,0); archShape.lineTo(.2,1.95); archShape.absarc(0,1.95,.2,0,Math.PI,false); archShape.lineTo(-.2,0);
  const archGeometry = new THREE.ExtrudeGeometry(archShape,{depth:.045,bevelEnabled:false,curveSegments:16});
  for (const x of [-5.45,4.95]) {
    box(x,2.05,2.69,.99,3.8,.4,m.gold);
    box(x-.53,2.05,2.87,.08,3.9,.1,m.cream); box(x+.53,2.05,2.87,.08,3.9,.1,m.cream);
    const arch = new THREE.Mesh(archGeometry,m.glass); arch.position.set(x,.52,2.903); root.add(arch);
    box(x,1.57,2.965,.035,2.09,.025,m.redwood);
    for (const yy of [.91,1.45,1.99,2.48]) box(x,yy,2.968,.4,.035,.025,m.redwood);
    box(x,3.34,2.92,.52,.23,.035,m.cream);
    instance(sphereGeometry,m.gold,x,3.34,2.964,.085,.085,.025);
    box(x,3.9,2.56,1.2,.19,1.03,m.cream);
    box(x,4.13,2.54,.84,.35,.78,m.wall);
    box(x,4.12,2.95,.26,.22,.025,m.glass);
    hipRoof(x,4.33,2.54,1.38,1.22,.37,m.roof);
    box(x,4.72,2.54,.06,.19,.06,m.brass);
  }

  // Rear wings enclose a genuine open courtyard, with accessible rooftop terraces.
  function wing(x: number,z: number,w: number,d: number,h: number) {
    solid(x,h/2+.17,z,w,h,d,m.wall,2);
    box(x,h+.24,z,w+.18,.16,d+.18,m.cream);
    box(x,h+.34,z,w-.12,.08,d-.12,m.roofTop);
    for (const side of [-1,1]) {
      box(x,h+.5,z+side*d/2,w,.25,.085,m.cream);
      box(x+side*w/2,h+.5,z,.085,.25,d,m.cream);
      const count=Math.max(2,Math.floor(w/.68));
      for(let j=0;j<count;j++) for(let f=0;f<2;f++) {
        const xx=x-w/2+.35+j*(w-.7)/(count-1);
        box(xx,.87+f*1.02,z+side*(d/2+.025),.42,.66,.045,m.glass);
        box(xx,.87+f*1.02,z+side*(d/2+.05),.025,.68,.04,m.redwood);
      }
      const rows=Math.max(2,Math.floor(d/.72));
      for(let j=0;j<rows;j++) for(let f=0;f<2;f++) box(x+side*(w/2+.025),.86+f*1.02,z-d/2+.4+j*(d-.8)/(rows-1),.045,.64,.43,m.glass);
    }
  }
  wing(-7.05,-2.88,3.12,6.1,2.76);
  wing(6.27,-2.66,2.87,5.7,2.45);
  wing(-.47,-5.1,10.05,1.73,2.4);
  box(6.28,2.98,-2.65,3.05,.12,2.25,m.pinkRoof);
  solid(1.1,1.81,-4.55,1.22,3.3,1.25,m.cream,2);
  hipRoof(1.1,3.54,-4.55,1.55,1.52,.35,m.roof);
  box(1.1,2.7,-3.895,.57,.71,.045,m.glass);
  box(-.35,.27,-2.35,9.65,.075,3.74,m.curb);
  for (let i=0;i<12;i++) box(-4.8+i*.8,.312,-2.35,.018,.008,3.7,m.paving);
  for (let i=0;i<6;i++) box(-.35,.313,-4.12+i*.67,9.6,.008,.018,m.paving);
  box(-.65,.34,-2.65,3.55,.12,1.8,m.grass);
  box(-.65,.4,-2.65,3.2,.06,1.48,m.paving);
  // Courtyard pergola and a raised roof garden along the main building.
  for(const x of [-1.7,.4]) for(const z of [-3.16,-2.14]) box(x,1.03,z,.07,1.45,.07,m.wood);
  for(let i=0;i<7;i++) box(-1.87+i*.42,1.77,-2.65,.105,.12,1.5,m.wood);
  box(-.7,1.67,-3.21,2.65,.13,.09,m.wood); box(-.7,1.67,-2.09,2.65,.13,.09,m.wood);
  for(const x of [-7.4,-5.9,-4.4,-2.9,-1.4,.1,1.6,3.1,4.6,6.1]) {
    box(x,3.91,-.02,1.1,.31,.5,m.cream); box(x,4.1,-.02,1.01,.13,.44,m.grass);
    for(let j=0;j<3;j++) instance(sphereGeometry,m.leaf,x-.31+j*.31,4.22,-.02,.22,.22,.19);
  }
  for(const x of [-4.6,3.7]) {
    box(x,.48,-3.73,1.02,.42,.65,m.cream); box(x,.74,-3.73,.94,.1,.56,m.grass);
    instance(sphereGeometry,m.leaf,x,1.16,-3.73,.43,.54,.35);
  }
  box(-.46,.35,-.2,8.3,.035,.04,m.cyan);

  function textPanel(text: string,x: number,y: number,z: number,w: number,h: number,color: string,background?: string) {
    const canvas=document.createElement("canvas");canvas.width=1536;canvas.height=256;
    const ctx=canvas.getContext("2d")!;
    if(background){ctx.fillStyle=background;ctx.fillRect(0,0,canvas.width,canvas.height);}
    ctx.fillStyle=color;ctx.font='600 166px "PingFang SC", "Microsoft YaHei", sans-serif';ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(text,768,135,1430);
    const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;textures.push(texture);
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:texture,transparent:true,toneMapped:false,side:THREE.DoubleSide}));mesh.position.set(x,y,z);root.add(mesh);
  }
  box(-.85,4.25,1.76,6.25,.65,.12,m.roof);
  for(const x of [-3.6,-.8,2]) box(x,3.95,1.76,.045,.66,.045,m.chrome);
  textPanel("海南海商智谷",-.85,4.26,1.831,5.98,.52,"#d8efc3");
  box(-.85,4.61,1.76,6.3,.035,.14,m.cyan);
  textPanel("创新创业 · 共创未来",7.72,2.79,2.61,2.48,.37,"#d97968");

  // Close-up entry references: slatted timber lintel, glazed doors, columns and red lanterns.
  const entranceX=1.75;
  solid(entranceX,.8,2.642,2.3,1.35,.07,m.woodDark,3);
  box(entranceX,1.52,3.02,2.85,.22,1.09,m.woodDark);
  box(entranceX,1.78,3.08,2.8,.37,.28,m.wood);
  for(let i=0;i<6;i++) box(entranceX,1.61+i*.062,3.241,2.78,.017,.025,m.woodDark);
  textPanel("海 商 孵 化 器",entranceX,1.78,3.264,2.61,.275,"#faf5e7");
  box(entranceX,1.455,3.49,2.82,.025,.04,m.warm);
  for(const x of [entranceX-1.22,entranceX+1.22]) {
    instance(cylinderGeometry,m.stone,x,.81,3.32,.11,1.37,.11);
    instance(cylinderGeometry,m.cream,x,.2,3.32,.145,.12,.145);
    box(x,1.46,3.32,.31,.11,.31,m.cream);
  }
  for(let j=0;j<4;j++) {
    const xx=entranceX-.78+j*.52;
    box(xx,.8,2.72,.493,1.13,.055,m.glassWarm);
    box(xx-.252,.8,2.76,.035,1.17,.06,m.cream);
    box(xx,.23,2.77,.53,.045,.075,m.cream); box(xx,1.37,2.77,.53,.045,.075,m.cream);
    box(xx,.67,2.782,.5,.027,.018,m.roof);
  }
  box(entranceX+.17,.74,2.827,.015,.21,.022,m.brass); box(entranceX-.17,.74,2.827,.015,.21,.022,m.brass);
  for(const x of [entranceX-.77,entranceX+.77]) {
    box(x,1.29,3.19,.018,.29,.018,m.brass);
    instance(sphereGeometry,m.lantern,x,1.12,3.19,.15,.177,.15);
    instance(cylinderGeometry,m.brass,x,1.28,3.19,.082,.036,.082);
    instance(cylinderGeometry,m.brass,x,.96,3.19,.065,.032,.065);
    for(let j=0;j<4;j++) box(x-.033+j*.022,.87,3.19,.007,.15,.007,m.lantern);
  }
  for(const z of [2.95,3.25]) box(entranceX,1.406,z,.1,.013,.08,m.warm);
  for(let i=0;i<3;i++) box(entranceX,.12+i*.048,3.63-i*.13,2.62,.065,.43,m.stone);
  box(entranceX,.284,3.15,1.3,.018,.48,m.lantern);
  for(const x of [entranceX-1.43,entranceX+1.43]) {
    box(x,.31,3.58,.38,.32,.43,m.stone);
    box(x,.49,3.58,.42,.06,.46,m.cream);
    instance(sphereGeometry,m.stone,x,.69,3.58,.16,.21,.22);
    instance(sphereGeometry,m.stone,x,.89,3.68,.17,.17,.16);
    instance(sphereGeometry,m.stone,x,.87,3.81,.115,.08,.06);
    for(const side of [-1,1]) instance(sphereGeometry,m.stone,x+side*.105,.99,3.65,.075,.07,.06);
    box(x-.1,.58,3.77,.07,.13,.13,m.stone);box(x+.1,.58,3.77,.07,.13,.13,m.stone);
  }

  // Curved street echoes the aerial reference instead of a generic square plaza.
  const roadCurve=new THREE.CatmullRomCurve3([new THREE.Vector3(-11.25,.115,-4.8),new THREE.Vector3(-10.9,.115,.4),new THREE.Vector3(-8.7,.115,4.6),new THREE.Vector3(-3.8,.115,6.3),new THREE.Vector3(3.8,.115,6.62),new THREE.Vector3(11.5,.115,5.5)]);
  const roadVertices:number[]=[], roadIndices:number[]=[], railLeft:THREE.Vector3[]=[], railRight:THREE.Vector3[]=[];
  for(let i=0;i<=100;i++) {
    const t=i/100,point=roadCurve.getPoint(t),dir=roadCurve.getTangent(t),side=new THREE.Vector3(-dir.z,0,dir.x).normalize().multiplyScalar(.86);
    const a=point.clone().add(side),b=point.clone().sub(side);roadVertices.push(a.x,a.y,a.z,b.x,b.y,b.z);railLeft.push(a.clone().setY(.14));railRight.push(b.clone().setY(.14));
    if(i<100){const n=i*2;roadIndices.push(n,n+1,n+2,n+1,n+3,n+2);}
  }
  const roadGeometry=new THREE.BufferGeometry();roadGeometry.setAttribute("position",new THREE.Float32BufferAttribute(roadVertices,3));roadGeometry.setIndex(roadIndices);roadGeometry.computeVertexNormals();
  const road=new THREE.Mesh(roadGeometry,new THREE.MeshStandardMaterial({color:0x243d3a,roughness:.94,side:THREE.DoubleSide}));road.receiveShadow=true;root.add(road);
  for(const rail of [railLeft,railRight])root.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(rail),new THREE.LineBasicMaterial({color:0xbed8ad,transparent:true,opacity:.55})));
  for(let i=0;i<39;i++) {
    const t=(i+.4)/39,point=roadCurve.getPointAt(t),dir=roadCurve.getTangentAt(t);
    box(point.x,.129,point.z,.045,.012,.3,m.white,Math.atan2(dir.x,dir.z));
  }
  for(let i=0;i<8;i++) box(9.4+i*.14,.14,5.82,.065,.016,1.6,m.white,.08);
  const carColors=[standard(0xe7ead8,.35,.35),standard(0x375f7a,.35,.4),standard(0x89978c,.35,.35)];
  [0.2,0.58,0.83].forEach((t,i)=>{
    const pos=roadCurve.getPointAt(t),tan=roadCurve.getTangentAt(t),ry=Math.atan2(tan.x,tan.z),group=new THREE.Group();group.position.copy(pos);group.rotation.y=ry;root.add(group);
    const parts:[[number,number,number],[number,number,number],THREE.Material][]=[[[0,.21,0],[.55,.22,1.03],carColors[i]],[[0,.4,-.07],[.47,.22,.56],m.glass],[[0,.53,-.07],[.48,.045,.55],carColors[i]],[[0,.2,.52],[.4,.045,.025],m.warm]];
    for(const [p,s,mat]of parts){const mesh=new THREE.Mesh(boxGeometry,mat);mesh.position.set(...p);mesh.scale.set(...s);mesh.castShadow=true;group.add(mesh);}
    for(const x of [-.29,.29])for(const z of [-.33,.33]){const wheel=new THREE.Mesh(cylinderGeometry,m.black);wheel.position.set(x,.16,z);wheel.scale.set(.13,.07,.13);wheel.rotation.z=Math.PI/2;group.add(wheel);}
  });

  // Geometric palm fronds, trunks and layered planting cast real three-dimensional shadows.
  const leafVertices:number[]=[],leafIndices:number[]=[];
  for(let i=0;i<=10;i++){const t=i/10,w=Math.sin(Math.PI*t)*.21,y=Math.sin(t*Math.PI)*.25-t*t*.43,z=t*1.64;leafVertices.push(-w,y,z,w,y,z);if(i<10){const n=i*2;leafIndices.push(n,n+1,n+2,n+1,n+3,n+2);}}
  const leafGeometry=new THREE.BufferGeometry();leafGeometry.setAttribute("position",new THREE.Float32BufferAttribute(leafVertices,3));leafGeometry.setIndex(leafIndices);leafGeometry.computeVertexNormals();
  function palm(x:number,z:number,height=2.3,scale=1) {
    instance(cylinderGeometry,m.trunk,x,height/2+.14,z,.065,height,.065,0,0,.035);
    for(let i=0;i<9;i++){const angle=i*Math.PI*2/9;instance(leafGeometry,m.leaf,x+.035,height+.18,z,scale,scale,scale,.05,angle,.02);}
    for(let i=0;i<3;i++)instance(sphereGeometry,m.woodDark,x+Math.cos(i*2)*.1,height+.11,z+Math.sin(i*2)*.1,.09,.1,.09);
    box(x,.15,z,.73,.06,.73,m.grass);
  }
  for(const [x,z,h] of [[-8.8,3.77,2.6],[-6.9,3.85,2.2],[-4.7,4.07,2.65],[-2.5,4.3,2.4],[-.3,4.43,2.75],[3.8,4.35,2.6],[6.2,4.18,2.25],[8.8,3.89,2.6],[-10,-2.3,2.3],[-9.6,.7,2.65],[10.2,-3.7,2.3],[10.4,-.4,2.5],[-5.7,-6.7,2.1],[4.1,-6.8,2.1]])palm(x,z,h,.75);
  for(const [x,z]of [[-4.5,-2.3],[3.8,-2.8],[-8.8,-6.5],[8.3,-5.7]]) {
    instance(cylinderGeometry,m.trunk,x,.73,z,.055,1.1,.055);
    instance(sphereGeometry,m.leaf,x,1.43,z,.49,.62,.49);
  }
  for(const x of [-7.5,-3.5,.3,4.5,8.3]) {
    box(x,.78,4.67,.033,1.3,.033,m.chrome);
    box(x,1.46,4.67,.28,.055,.16,m.warm);
  }
  for(let i=0;i<8;i++) {
    box(10.02,.126,-4.9+i*.55,1.2,.01,.022,m.white);
    box(10.62,.126,-4.62+i*.55,.022,.01,.53,m.white);
  }
  // Assemble repeated window, trim and planting geometry into efficient GPU instances.
  for(const batch of batches.values()) {
    const mesh=new THREE.InstancedMesh(batch.geometry,batch.material,batch.matrices.length);
    batch.matrices.forEach((matrix,i)=>mesh.setMatrixAt(i,matrix));mesh.instanceMatrix.needsUpdate=true;
    mesh.castShadow=batch.material instanceof THREE.MeshStandardMaterial;mesh.receiveShadow=true;root.add(mesh);
  }
  const hotspots=[
    {name:"沿街主楼",view:1,point:new THREE.Vector3(-5.45,5.1,2.54)},
    {name:"屋顶庭院",view:2,point:new THREE.Vector3(-1.1,3.2,-3.5)},
    {name:"孵化器入口",view:3,point:new THREE.Vector3(entranceX,2.05,3.45)},
    {name:"椰林街区",view:0,point:new THREE.Vector3(8.8,3.4,3.89)},
  ];
  return {root,pickables,textures,hotspots,glass:m.glass,glassWarm:m.glassWarm};
}
