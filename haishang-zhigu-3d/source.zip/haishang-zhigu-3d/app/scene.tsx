"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { createCampusModel } from "./campus-model";
import { createSpatialDirector, JourneyPhase } from "./spatial-director";
import SpacePhoto, { PhotoView } from "./space-photo";
import type { SpaceId } from "./tour-data";
import { TourId, tourMarkerIds, tourMarkerLabels, tourSpaces } from "./tour-data";

type Props = { room: SpaceId | null; roomRequest: number; photoView: PhotoView; onPhotoView: (view:PhotoView)=>void; skipJourney: number; onJourneyPhase: (phase: JourneyPhase) => void; day: boolean; autoRotate: boolean; reset: number; view: number; viewRequest: number; zoomCommand: number; immersive: boolean; tourMode: boolean; onTourSelect: (id: TourId) => void; onSelect: (view: number) => void; onReady: () => void };
const labels = ["沿街主楼", "屋顶庭院", "孵化器入口", "椰林街区"];
const viewIds = [1, 2, 3, 0];
const views = [
  { camera: new THREE.Vector3(22, 20, 28), target: new THREE.Vector3(0, 1.25, 0) },
  { camera: new THREE.Vector3(4, 7.2, 31), target: new THREE.Vector3(-.4, 1.9, 1.25) },
  { camera: new THREE.Vector3(10, 23, 15), target: new THREE.Vector3(-.3, 1.1, -2.4) },
  { camera: new THREE.Vector3(4.3, 2.75, 8.25), target: new THREE.Vector3(1.75, 1.08, 3.05) },
];

export default function CampusScene(props: Props) {
  const host = useRef<HTMLDivElement>(null);
  const veil = useRef<HTMLDivElement>(null);
  const labelRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const latest = useRef(props);
  const [failed, setFailed] = useState(false);
  const [photo, setPhoto] = useState<{id:SpaceId;version:number}|null>(null);
  latest.current = props;

  useEffect(() => {
    const container = host.current!;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" }); }
    catch { setFailed(true); latest.current.onReady(); return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65));
    renderer.setClearColor(0x000000, 0);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.domElement.setAttribute("role", "img");
    renderer.domElement.setAttribute("aria-label", "海商智谷三维建筑模型：360 度拖动旋转、滚轮或双指缩放；方向键旋转，加减键缩放。建筑按实景照片参考建模。");
    renderer.domElement.tabIndex = 0;
    container.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, 1, .1, 150);
    camera.position.copy(views[0].camera);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(views[0].target);
    controls.enableDamping = true; controls.dampingFactor = .055; controls.enablePan = false;
    controls.minDistance = 3.5; controls.maxDistance = 65;
    controls.minPolarAngle = .15; controls.maxPolarAngle = Math.PI / 2 - .05;
    controls.autoRotateSpeed = .22; controls.rotateSpeed = .62; controls.zoomSpeed = .7;
    controls.update();
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(1,1),.33,.55,.94);
    composer.addPass(bloom); composer.addPass(new OutputPass());
    const ambient = new THREE.AmbientLight(0xc1e4df, 1.15); scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xffe6bf, 3.2); sun.position.set(-9,22,12); sun.castShadow = true;
    sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-20;sun.shadow.camera.right=20;sun.shadow.camera.top=18;sun.shadow.camera.bottom=-18;sun.shadow.camera.near=.5;sun.shadow.camera.far=65;
    sun.shadow.bias=-.00025;sun.shadow.normalBias=.04;scene.add(sun);
    const rim = new THREE.DirectionalLight(0x57dec6,2.6);rim.position.set(12,9,-12);scene.add(rim);
    const fill = new THREE.PointLight(0x79f2d4,50,30,2);fill.position.set(0,8,6);scene.add(fill);
    const model = createCampusModel();scene.add(model.root);
    const entryLight = new THREE.PointLight(0xffd191,4,4,2);entryLight.position.set(1.75,1.3,3.5);model.root.add(entryLight);

    // Floating holographic platform and orbiting light, as in the first design.
    const lineMaterial = new THREE.LineBasicMaterial({color:0x5b9e80,transparent:true,opacity:.12});
    for(let i=-13;i<=13;i++) {
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(i*1.25,-1.2,-16),new THREE.Vector3(i*1.25,-1.2,16)]),lineMaterial));
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-17,-1.2,i*1.25),new THREE.Vector3(17,-1.2,i*1.25)]),lineMaterial));
    }
    for(const radius of [14.2,16]) {
      const points=Array.from({length:161},(_,i)=>{const a=i/160*Math.PI*2;return new THREE.Vector3(Math.cos(a)*radius,-1.03,Math.sin(a)*radius*.72)});
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:0x8ecc9c,transparent:true,opacity:.18})));
    }
    const orbitCurve = new THREE.CatmullRomCurve3(Array.from({length:81},(_,i)=>{const a=i/80*Math.PI*2;return new THREE.Vector3(Math.cos(a)*14.3,1.65+Math.sin(a)*3.7,Math.sin(a)*10.9)}),true);
    const orbit = new THREE.Mesh(new THREE.TubeGeometry(orbitCurve,200,.014,5,true),new THREE.MeshBasicMaterial({color:0xb6d88b,transparent:true,opacity:.42}));scene.add(orbit);
    const orbiter = new THREE.Mesh(new THREE.SphereGeometry(.07,10,10),new THREE.MeshBasicMaterial({color:new THREE.Color(0xbef997).multiplyScalar(3)}));scene.add(orbiter);
    let seed=29;const rand=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646};
    const positions=new Float32Array(140*3);for(let i=0;i<positions.length;i+=3){positions[i]=(rand()-.5)*42;positions[i+1]=rand()*16-2;positions[i+2]=(rand()-.5)*32;}
    const particlesGeometry=new THREE.BufferGeometry();particlesGeometry.setAttribute("position",new THREE.BufferAttribute(positions,3));
    const particles=new THREE.Points(particlesGeometry,new THREE.PointsMaterial({color:0xc9e8b2,size:.025,transparent:true,opacity:.6}));scene.add(particles);

    const exterior = new THREE.Group();
    [...scene.children].filter(object=>!(object instanceof THREE.Light)).forEach(object=>exterior.add(object));
    scene.add(exterior);
    let width=1,height=1,photoActive=false;
    const resize=()=>{
      width=Math.max(1,container.clientWidth);height=Math.max(1,container.clientHeight);
      camera.aspect=width/height;camera.zoom=Math.min(1,Math.max(.72,camera.aspect/1.25));camera.updateProjectionMatrix();
      renderer.setSize(width,height);composer.setSize(width,height);
    };
    const observer=new ResizeObserver(resize);observer.observe(container);resize();
    const motionQuery=window.matchMedia("(prefers-reduced-motion: reduce)");
    const director=createSpatialDirector({camera,controls,exterior,veil:veil.current!,onPhoto:id=>setPhoto(p=>id?{id,version:(p?.version??0)+1}:null),onPhase:phase=>latest.current.onJourneyPhase(phase),reduced:()=>motionQuery.matches});
    let transition=false,goalCamera=views[0].camera.clone(),goalTarget=views[0].target.clone();
    const onStart=()=>{transition=false;renderer.domElement.style.cursor="grabbing";};
    const onEnd=()=>{renderer.domElement.style.cursor="grab";};
    controls.addEventListener("start",onStart);controls.addEventListener("end",onEnd);
    renderer.domElement.style.cursor="grab";
    const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
    let downX=0,downY=0;
    const down=(e:PointerEvent)=>{downX=e.clientX;downY=e.clientY;};
    const up=(e:PointerEvent)=>{
      if(director.active||director.busy)return;
      if(Math.hypot(e.clientX-downX,e.clientY-downY)>5)return;
      const rect=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);
      raycaster.setFromCamera(pointer,camera);
      const hit=raycaster.intersectObjects(model.pickables)[0];if(hit)latest.current.onSelect(hit.object.userData.view);
    };
    const keydown=(e:KeyboardEvent)=>{
      if(!["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","+","=","-"].includes(e.key))return;
      e.preventDefault();if(director.busy||director.active)return;transition=false;
      const offset=camera.position.clone().sub(controls.target),spherical=new THREE.Spherical().setFromVector3(offset);
      if(e.key==="ArrowLeft")spherical.theta-=.12;if(e.key==="ArrowRight")spherical.theta+=.12;
      if(e.key==="ArrowUp")spherical.phi-=.09;if(e.key==="ArrowDown")spherical.phi+=.09;
      spherical.phi=THREE.MathUtils.clamp(spherical.phi,controls.minPolarAngle,controls.maxPolarAngle);
      if(["+","=","-"].includes(e.key))spherical.radius=THREE.MathUtils.clamp(spherical.radius*(e.key==="-"?1.13:.87),controls.minDistance,controls.maxDistance);
      camera.position.copy(controls.target).add(offset.setFromSpherical(spherical));controls.update();
    };
    const lost=(e:Event)=>{e.preventDefault();setFailed(true);latest.current.onReady();};
    renderer.domElement.addEventListener("pointerdown",down);renderer.domElement.addEventListener("pointerup",up);renderer.domElement.addEventListener("keydown",keydown);renderer.domElement.addEventListener("webglcontextlost",lost);
    const projected=new THREE.Vector3();
    let frame=0,lastTime=0,elapsed=0,lastView=latest.current.viewRequest,lastReset=latest.current.reset,lastZoom=latest.current.zoomCommand;
    let lastRoom=-1,lastSkip=latest.current.skipJourney;
    const animate=(time:number)=>{
      frame=requestAnimationFrame(animate);if(document.hidden){lastTime=time;return;}
      const dt=Math.min((time-lastTime)/1000,.05);lastTime=time;const p=latest.current,smooth=1-Math.exp(-dt*5);
      if(p.roomRequest!==lastRoom){transition=false;director.request(p.room);lastRoom=p.roomRequest;}
      if(p.skipJourney!==lastSkip){director.skip();lastSkip=p.skipJourney;}
      if(!director.active&&!director.busy&&(p.viewRequest!==lastView||p.reset!==lastReset)){
        const index=p.reset!==lastReset?0:p.view;goalCamera.copy(views[index].camera);goalTarget.copy(views[index].target);transition=true;
        lastView=p.viewRequest;lastReset=p.reset;
      }
      if(p.zoomCommand!==lastZoom&&!director.busy){
        transition=false;const delta=p.zoomCommand-lastZoom,offset=camera.position.clone().sub(controls.target);
        offset.setLength(THREE.MathUtils.clamp(offset.length()*Math.pow(.84,delta),controls.minDistance,controls.maxDistance));camera.position.copy(controls.target).add(offset);lastZoom=p.zoomCommand;
      }
      if(transition){
        const f=motionQuery.matches?1:smooth;camera.position.lerp(goalCamera,f);controls.target.lerp(goalTarget,f);
        if(camera.position.distanceTo(goalCamera)<.02&&controls.target.distanceTo(goalTarget)<.02){camera.position.copy(goalCamera);controls.target.copy(goalTarget);transition=false;}
      }
      director.update(dt);
      if(photoActive!==director.active){photoActive=director.active;renderer.domElement.setAttribute("aria-hidden",String(photoActive));renderer.domElement.tabIndex=photoActive?-1:0;}
      controls.autoRotate=p.autoRotate&&!director.active&&!director.busy&&!transition&&!motionQuery.matches;controls.update(dt);
      if(p.autoRotate&&!director.active&&!director.busy&&!motionQuery.matches){elapsed+=dt;model.root.position.y=Math.sin(elapsed*.55)*.045;particles.rotation.y=elapsed*.003;}
      orbiter.position.copy(orbitCurve.getPointAt((elapsed*.019)%1));
      ambient.intensity+=((p.day?2:1.15)-ambient.intensity)*smooth;
      sun.intensity+=((p.day?4.5:3.2)-sun.intensity)*smooth;
      rim.intensity+=((p.day?1.5:2.6)-rim.intensity)*smooth;
      bloom.strength+=((p.day?.12:.33)-bloom.strength)*smooth;
      model.glass.emissiveIntensity+=((p.day?.05:.2)-model.glass.emissiveIntensity)*smooth;
      model.glassWarm.emissiveIntensity+=((p.day?.08:.28)-model.glassWarm.emissiveIntensity)*smooth;
      model.root.updateMatrixWorld();
      for(let i=0;i<model.hotspots.length;i++){
        const label=labelRefs.current[i];if(!label)continue;
        projected.copy(model.hotspots[i].point).applyMatrix4(model.root.matrixWorld).project(camera);
        const px=(projected.x*.5+.5)*width,py=(-projected.y*.5+.5)*height;
        const visible=!director.active&&!director.busy&&projected.z<1&&projected.z>0&&px>30&&px<width-70&&py>60&&py<height-45&&(p.tourMode||p.view!==3||i===2);
        label.style.transform=`translate(${px-22}px,${py-39}px)`;label.style.opacity=visible?"1":"0";label.style.visibility=visible?"visible":"hidden";
        label.style.borderColor=p.view===model.hotspots[i].view?"#c3f87988":"#b8e8b544";
      }
      if(!director.active)composer.render();
    };
    frame=requestAnimationFrame(animate);latest.current.onReady();
    return()=>{
      cancelAnimationFrame(frame);observer.disconnect();controls.dispose();
      renderer.domElement.removeEventListener("pointerdown",down);renderer.domElement.removeEventListener("pointerup",up);renderer.domElement.removeEventListener("keydown",keydown);renderer.domElement.removeEventListener("webglcontextlost",lost);
      const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>();
      scene.traverse(object=>{const mesh=object as THREE.Mesh;if(mesh.geometry)geometries.add(mesh.geometry);if(mesh.material)(Array.isArray(mesh.material)?mesh.material:[mesh.material]).forEach(mat=>materials.add(mat));if(object instanceof THREE.InstancedMesh)object.dispose();});
      geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());model.textures.forEach(t=>t.dispose());sun.shadow.dispose();bloom.dispose();composer.dispose();renderer.dispose();renderer.domElement.remove();
    };
  },[]);
  useEffect(()=>{
    if(!props.room)return;
    // Load the requested real frame during the unchanged exterior approach.
    for(const item of tourSpaces){const img=new Image();img.src=item.image;}
  },[props.room]);
  return <div ref={host} className="campus-canvas">
    {photo&&<SpacePhoto key={`${photo.id}-${photo.version}`} id={photo.id} view={props.photoView} onView={props.onPhotoView}/>}
    <div ref={veil} className="journey-veil" aria-hidden="true"/>
    {!failed&&labels.map((name,i)=><button key={name} ref={el=>{labelRefs.current[i]=el;}} className="scene-label" onClick={()=>props.tourMode ? props.onTourSelect(tourMarkerIds[i]) : props.onSelect(viewIds[i])} aria-label={props.tourMode ? `进入${tourMarkerLabels[i]}实景空间` : `近看${name}`}><span className="label-dot"/>{props.tourMode ? tourMarkerLabels[i] : name}{props.tourMode ? <span className="label-video">实景</span> : <ArrowUpRight/>}</button>)}
    {failed&&<div className="canvas-fallback"><strong>当前设备暂时无法显示 3D 建筑。</strong><p>请使用支持 WebGL 的浏览器并启用图形加速。园区介绍和服务内容仍可查看。</p></div>}
  </div>;
}
