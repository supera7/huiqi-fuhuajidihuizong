"use client";

import { ArrowLeft, ArrowUpRight, Film, ImageIcon, Maximize, RotateCcw, SkipForward, ZoomIn } from "lucide-react";
import type { PhotoView } from "./space-photo";
import type { JourneyPhase } from "./spatial-director";
import { tourSpaces, SpaceId } from "./tour-data";

type Props = { room:SpaceId|null; phase:JourneyPhase; view:PhotoView; onEnter:(id:SpaceId)=>void; onLeave:()=>void; onView:(view:PhotoView)=>void; onSkip:()=>void; onVideo:(id:SpaceId)=>void; };
const phases = ["靠近建筑", "穿过入口", "走进空间"];
const phaseIndex = {campus:0,approach:0,threshold:1,entering:2,inside:3,returning:-1};
const views = [{id:"full",name:"完整画面",icon:Maximize},{id:"detail",name:"放大细看",icon:ZoomIn}] as const;

export default function SpatialHud(p:Props) {
  const space = tourSpaces.find(item=>item.id===p.room);
  const busy = p.phase!=="inside";
  return <div className="spatial-hud">
    <div className="spatial-top">
      <button className="spatial-back" autoFocus onClick={p.onLeave} disabled={p.phase==="returning"}><ArrowLeft size={17}/><span>返回园区</span></button>
      <a className="spatial-brand" href="./">海商智谷<span>.</span><small>SPATIAL JOURNEY</small></a>
      {space&&<button className="spatial-video" onClick={()=>p.onVideo(space.id)}><Film size={16}/><span>观看原片</span><ArrowUpRight size={14}/></button>}
    </div>
    <div className="spatial-title" aria-live="polite">
      <span className="spatial-kicker"><span/>{p.phase==="returning"?"RETURN TO THE VALLEY":"STEP INSIDE · 园区实景"}</span>
      <h2>{space?.name??"回到园区"}<span>{space?String(tourSpaces.indexOf(space)+1).padStart(2,"0"):"↗"}</span></h2>
      <p>{space?space.features.join(" · "):"重新俯瞰海商智谷，继续探索园区。"}</p>
    </div>
    {busy&&<div className={`journey-status ${p.phase==="entering"?"is-revealing":""}`} role="status">
      {p.phase==="returning"?<span className="journey-return">正在回到园区全景</span>:<ol>{phases.map((name,i)=><li key={name} className={phaseIndex[p.phase]===i?"current":phaseIndex[p.phase]>i?"complete":""}><span>{i+1}</span>{name}</li>)}</ol>}
      <button onClick={p.onSkip}>跳过运镜<SkipForward size={14}/></button>
    </div>}
    <div className="spatial-bottom">
      <div className="spatial-tool-row">
        <div className="spatial-views" role="group" aria-label="实景图片查看方式">{views.map(v=><button key={v.id} aria-pressed={p.view===v.id} disabled={busy} onClick={()=>p.onView(v.id)}><v.icon size={15}/>{v.name}</button>)}</div>
        <div className="spatial-extra"><button disabled={busy||!space} onClick={()=>space&&p.onEnter(space.id)} aria-label="重播实景入场"><RotateCcw size={17}/><span>重播入场</span></button></div>
      </div>
      <div className="spatial-help"><span><ImageIcon size={14}/>{p.view==="detail"?"拖动查看 · 滚轮 / 双指缩放":"完整实景 · 可放大查看"}</span><small>原图取自园区视频 · 保留原始画面</small></div>
      <nav className="spatial-filmstrip" aria-label="切换实景功能空间">{tourSpaces.map((item,i)=><button key={item.id} aria-current={p.room===item.id?"true":undefined} onClick={()=>p.onEnter(item.id)}><img src={item.image} alt="" width={120} height={68}/><span><small>0{i+1}</small>{item.name}</span></button>)}</nav>
    </div>
  </div>;
}
