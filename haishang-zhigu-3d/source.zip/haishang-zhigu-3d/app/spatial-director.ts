import * as THREE from "three";
import type { OrbitControls } from "three/addons/controls/OrbitControls.js";
import type { SpaceId } from "./tour-data";

export type JourneyPhase = "campus" | "approach" | "threshold" | "entering" | "inside" | "returning";
type Pose = {camera:THREE.Vector3;target:THREE.Vector3;fov:number};
type Options = { camera:THREE.PerspectiveCamera; controls:OrbitControls; exterior:THREE.Group; veil:HTMLDivElement; onPhoto:(id:SpaceId|null)=>void; onPhase:(phase:JourneyPhase)=>void; reduced:()=>boolean };
const ease=(t:number)=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*t*(t*(t*6-15)+10);};
const pose=(camera:number[],target:number[],fov=36):Pose=>({camera:new THREE.Vector3(...camera),target:new THREE.Vector3(...target),fov});
const overview=pose([22,20,28],[0,1.25,0]);
// Preserve the first two camera stages, including their positions, easing and timings.
const approach=pose([4.3,2.75,8.25],[1.75,1.25,2.65],45);
const threshold=pose([1.75,1.65,3.12],[1.75,1.5,-2],58);

export function createSpatialDirector(o:Options) {
  let phase:JourneyPhase="campus",photoShown=false;
  let journey:{type:"enter"|"switch"|"leave";time:number;duration:number;from:Pose;id:SpaceId|null;swapped:boolean}|null=null;
  const read=():Pose=>({camera:o.camera.position.clone(),target:o.controls.target.clone(),fov:o.camera.fov});
  const report=(next:JourneyPhase)=>{if(phase!==next){phase=next;o.onPhase(next);}};
  function apply(from:Pose,to:Pose,t:number) {
    const e=ease(t);o.camera.position.lerpVectors(from.camera,to.camera,e);o.controls.target.lerpVectors(from.target,to.target,e);
    o.camera.fov=THREE.MathUtils.lerp(from.fov,to.fov,e);o.camera.updateProjectionMatrix();
  }
  const set=(p:Pose)=>apply(p,p,1);
  function showPhoto(id:SpaceId) {o.onPhoto(id);o.exterior.visible=false;photoShown=true;}
  function showCampus() {o.onPhoto(null);o.exterior.visible=true;photoShown=false;}
  function finish() {
    if(!journey)return;
    if(journey.type==="leave") {showCampus();set(overview);report("campus");}
    else {if(!journey.swapped)showPhoto(journey.id!);report("inside");}
    o.veil.style.opacity="0";journey=null;o.controls.enabled=!photoShown;
  }
  function request(id:SpaceId|null) {
    o.controls.autoRotate=false;
    o.controls.enableDamping=false;o.controls.update();o.controls.enableDamping=true;
    if(id===null){
      if(!photoShown){journey=null;o.veil.style.opacity="0";o.controls.enabled=true;showCampus();set(overview);report("campus");return;}
      journey={type:"leave",time:0,duration:3.4,from:read(),id:null,swapped:false};report("returning");
    } else {
      journey={type:photoShown?"switch":"enter",time:0,duration:photoShown?1.8:6.2,from:read(),id,swapped:false};report(photoShown?"entering":"approach");
    }
    o.controls.enabled=false;
    if(o.reduced())finish();
  }
  function update(dt:number) {
    if(!journey)return;
    journey.time+=dt;const j=journey,t=j.time;
    if(j.type==="enter") {
      if(t<2.4){apply(j.from,approach,t/2.4);report("approach");}
      else if(t<3.45){apply(approach,threshold,(t-2.4)/1.05);report("threshold");}
      o.veil.style.opacity=String(t<3.45?ease((t-2.96)/.49):1-ease((t-3.45)/.7));
      if(t>=3.45){if(!j.swapped){showPhoto(j.id!);j.swapped=true;}report("entering");}
    } else if(j.type==="switch") {
      o.veil.style.opacity=String(t<.5?ease(t/.5):1-ease((t-.5)/.6));
      if(t>=.5&&!j.swapped){showPhoto(j.id!);j.swapped=true;}
    } else {
      o.veil.style.opacity=String(t<1.2?ease((t-.65)/.55):1-ease((t-1.2)/.65));
      if(t>=1.2){if(!j.swapped){showCampus();j.swapped=true;}apply(approach,overview,(t-1.2)/2.2);}
    }
    if(t>=j.duration)finish();
  }
  return {request,update,skip:finish,get active(){return photoShown;},get busy(){return journey!==null;},get phase(){return phase;}};
}
