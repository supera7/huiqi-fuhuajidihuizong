"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, ImageIcon, Film, Play, RotateCcw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { TOUR_VIDEO, TourId, SpaceId, tourSpaces, tourTime } from "./tour-data";

type Props = { onEnter: (id:SpaceId) => void; selection: TourId | null; onSelect: (id: TourId) => void; onClose: () => void };

export default function CampusTour({ selection, onSelect, onClose, onEnter }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const chaptersRef = useRef<HTMLElement>(null);
  const openerRef = useRef<HTMLElement | null>(null);
  const currentSelection = useRef(selection);
  currentSelection.current = selection;
  const [ended, setEnded] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [error, setError] = useState(false);
  const space = tourSpaces.find(item => item.id === selection);

  function playSelection() {
    const video = videoRef.current;
    if (!video || video.readyState < 1) return;
    const target = tourSpaces.find(item => item.id === currentSelection.current);
    video.currentTime = target?.start ?? 0;
    setEnded(false); setBlocked(false);
    void video.play().catch(() => setBlocked(true));
  }

  useEffect(() => {
    if (selection === null) return;
    setEnded(false); setBlocked(false); setError(false);
    playSelection();
    const chapters = chaptersRef.current;
    const active = chapters?.querySelector<HTMLButtonElement>('[aria-current="true"]');
    if (chapters && active) {
      if (selection === "all") chapters.scrollTop = 0;
      else if (active.offsetTop < chapters.scrollTop || active.offsetTop + active.offsetHeight > chapters.scrollTop + chapters.clientHeight)
        chapters.scrollTop = Math.max(0, active.offsetTop - chapters.clientHeight / 2);
    }
  }, [selection]);

  return <>
    <section className="real-spaces" id="real-spaces" aria-labelledby="real-spaces-heading">
      <div className="real-spaces-heading">
        <div><span className="section-kicker">走进园区 · 8 个实景空间</span><h2 id="real-spaces-heading">让每个空间，都触手可及。</h2><p>跟随镜头穿过园区入口，看看各个空间的真实模样。</p></div>
        <Button className="tour-film-button" variant="outline" onClick={() => onSelect("all")}><Play size={16} />观看完整短片<span>25 秒</span></Button>
      </div>
      <div className="real-spaces-grid">{tourSpaces.map((item, index) => <button className="real-space-card" key={item.id} onClick={() => onEnter(item.id)} aria-label={`进入${item.name}实景空间`}>
        <span className="real-space-image"><img src={item.image} alt={`${item.name}，截取自园区介绍视频`} loading="lazy" width={568} height={320} /><span className="space-number">0{index + 1}</span><span className="space-play"><ImageIcon size={20}/></span><span className="space-photo-tag">走进实景空间</span></span>
        <span className="space-card-copy"><span><strong>{item.name}</strong><small>{item.category}</small></span><ArrowUpRight size={19} /></span>
      </button>)}</div>
      <p className="tour-source-note">空间实景取自园区提供的介绍视频，保留拍摄时的真实画面。</p>
    </section>
    <Dialog open={selection !== null} onOpenChange={open => { if (!open) { videoRef.current?.pause(); onClose(); } }}>
      <DialogContent className="tour-dialog" showCloseButton={false}
        onOpenAutoFocus={() => { openerRef.current = document.activeElement as HTMLElement; }}
        onCloseAutoFocus={event => { event.preventDefault(); if (openerRef.current?.isConnected && openerRef.current.getClientRects().length) openerRef.current.focus(); else document.querySelector<HTMLButtonElement>(".spatial-back")?.focus(); }}>
        <DialogClose asChild><Button className="tour-close" variant="ghost" size="icon" aria-label="关闭实景导览"><X /></Button></DialogClose>
        <div className="tour-dialog-heading"><span className="section-kicker"><Film size={15} />园区实景导览</span><DialogTitle>{space?.name ?? "25 秒，走进海商智谷。"}</DialogTitle><DialogDescription>{space?.description ?? "观看园区原始介绍短片，或选择一个空间，跳转到对应画面。"}</DialogDescription></div>
        <div className="tour-player-layout">
          <div className="tour-player-column">
            <div className="tour-player">
              <video ref={videoRef} src={TOUR_VIDEO} poster={space?.image ?? "./cowork.jpg"} controls playsInline muted preload="metadata" aria-label={space ? `${space.name}实景片段` : "园区完整介绍视频"}
                onLoadedMetadata={playSelection}
                onError={() => setError(true)}
                onPlay={() => { setBlocked(false); setEnded(false); }}
                onTimeUpdate={event => { if (space && event.currentTarget.currentTime >= space.end) { event.currentTarget.pause(); event.currentTarget.currentTime = space.end - .06; setEnded(true); } }}
                onEnded={() => setEnded(true)}>
                <track kind="chapters" src="./campus-chapters.vtt" srcLang="zh" label="园区空间" />
                当前浏览器无法播放视频，可通过下方链接打开原片。
              </video>
              {error ? <div className="tour-video-notice" role="alert"><p>视频暂时无法播放</p><a href={TOUR_VIDEO} target="_blank" rel="noreferrer">打开原始视频<ArrowUpRight size={16} /></a></div> : (ended || blocked) && <div className="tour-replay"><Button onClick={playSelection}><RotateCcw size={17}/>{ended ? "重新播放" : "播放实景"}</Button></div>}
            </div>
            <div className="tour-playing-meta"><span>{space ? `${tourTime(space.start, true)} — ${tourTime(space.end, true)} · 空间片段` : "00:00 — 00:25 · 完整短片"}</span><span>{space?.category ?? "原始园区影像"}</span></div>
            {space && <div className="tour-features">{space.features.map(feature => <span key={feature}>{feature}</span>)}<Button variant="ghost" onClick={() => onSelect("all")}><Play size={14}/>接着看完整短片</Button></div>}
            {space&&<Button className="tour-enter-photo" onClick={()=>{videoRef.current?.pause();onEnter(space.id);}}><ImageIcon size={16}/>查看这个空间实景<ArrowUpRight size={16}/></Button>}
            <p className="tour-original-note">保留原视频画面与原声。片中优惠、政策、资质与联系方式以园区最新确认为准。</p>
          </div>
          <nav ref={chaptersRef} className="tour-chapters" aria-label="选择实景空间">
            <button className="tour-full-chapter" aria-current={selection === "all" ? "true" : undefined} onClick={() => { if (selection === "all") playSelection(); else onSelect("all"); }}><Film size={20}/><span>完整园区短片<small>从头观看 · 25 秒</small></span><Play size={15}/></button>
            {tourSpaces.map(item => <button key={item.id} aria-current={selection === item.id ? "true" : undefined} onClick={() => { if (selection === item.id) playSelection(); else onSelect(item.id); }}>
              <img src={item.image} width={80} height={46} alt=""/><span>{item.name}<small>{item.category}</small></span><span className="chapter-time">{tourTime(item.start)}</span>
            </button>)}
          </nav>
        </div>
      </DialogContent>
    </Dialog>
  </>;
}
